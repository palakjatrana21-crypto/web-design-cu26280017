t = (1, 2)
n = 3

print(t * n)