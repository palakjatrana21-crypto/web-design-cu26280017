numbers = [10, 20, 30, 40]
t = tuple(numbers)

print(t)