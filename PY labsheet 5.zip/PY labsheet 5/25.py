t1 = (10, 20, 30, 40)
t2 = (20, 40, 50)

difference = tuple(x for x in t1 if x not in t2)

print("Difference:", difference)