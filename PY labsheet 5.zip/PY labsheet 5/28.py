t = (10, 20, 10, 30, 20, 40, 10)
repeated = []

for item in t:
    if t.count(item) > 1 and item not in repeated:
        repeated.append(item)

print("Repeated items:", tuple(repeated))