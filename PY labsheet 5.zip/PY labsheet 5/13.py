t = (15, 5, 30, 10, 25)

print("Maximum:", max(t))
print("Minimum:", min(t))