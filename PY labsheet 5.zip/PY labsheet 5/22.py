t = ((1, 2), (3, 4), (5, 6))
result = ()

for sub in t:
    for item in sub:
        result += (item,)

print(result)