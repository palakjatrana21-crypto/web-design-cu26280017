data = [(1, "Aman"), (2, "Riya"), (3, "Rahul")]

numbers, names = zip(*data)

print("Numbers:", list(numbers))
print("Names:", list(names))