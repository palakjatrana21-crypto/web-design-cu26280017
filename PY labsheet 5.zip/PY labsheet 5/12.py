t = ('P', 'y', 't', 'h', 'o', 'n')
result = ""

for ch in t:
    result += ch

print(result)