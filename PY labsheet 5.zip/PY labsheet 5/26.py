t = (("Name", "Aman"), ("Age", 20), ("Marks", 85))

result = dict(t)
print(result)