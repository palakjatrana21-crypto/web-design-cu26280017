import sqlite3
import csv

con = sqlite3.connect("college.db")
cur = con.cursor()

cur.execute("SELECT * FROM students")
rows = cur.fetchall()

with open("students.csv", "w", newline="") as f:
    writer = csv.writer(f)
    writer.writerow(["ID", "Name", "Age", "Marks"])
    writer.writerows(rows)

con.close()
print("Data exported to CSV successfully!")