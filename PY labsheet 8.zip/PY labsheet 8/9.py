import sqlite3

con = sqlite3.connect("college.db")
cur = con.cursor()

data = [
    (2, "Riya", 21, 92),
    (3, "Rahul", 20, 75),
    (4, "Priya", 22, 88)
]

cur.executemany("INSERT INTO students VALUES (?, ?, ?, ?)", data)

con.commit()
print("Multiple records inserted!")

con.close()