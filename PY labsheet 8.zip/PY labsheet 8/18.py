import sqlite3

con = sqlite3.connect("college.db")
cur = con.cursor()

cur.execute("DELETE FROM students WHERE id = 3")

con.commit()
print("Student deleted successfully!")

con.close()