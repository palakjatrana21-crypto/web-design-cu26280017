import sqlite3

def insert_data(name, age, marks):
    con = sqlite3.connect("college.db")
    con.execute(
        "INSERT INTO students(name, age, marks) VALUES (?, ?, ?)",
        (name, age, marks)
    )
    con.commit()
    con.close()
    print("Record inserted!")

def fetch_data():
    con = sqlite3.connect("college.db")
    rows = con.execute("SELECT * FROM students").fetchall()

    for row in rows:
        print(row)

    con.close()

insert_data("Karan", 21, 86)
fetch_data()