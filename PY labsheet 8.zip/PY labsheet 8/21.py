import sqlite3

con = sqlite3.connect("college.db")
cur = con.cursor()

cur.execute("""
CREATE TABLE IF NOT EXISTS courses(
    course_id INTEGER PRIMARY KEY,
    student_id INTEGER,
    course_name TEXT
)
""")

cur.executemany(
    "INSERT INTO courses VALUES (?, ?, ?)",
    [
        (101, 1, "Python"),
        (102, 2, "DBMS"),
        (103, 4, "AI")
    ]
)

con.commit()
print("Courses created and data inserted!")

con.close()