import sqlite3
import csv

con = sqlite3.connect("college.db")
cur = con.cursor()

with open("students.csv", "r") as f:
    reader = csv.DictReader(f)

    for row in reader:
        cur.execute(
            "INSERT INTO students VALUES (?, ?, ?, ?)",
            (row["ID"], row["Name"], row["Age"], row["Marks"])
        )

con.commit()
con.close()

print("CSV data imported successfully!")