import sqlite3

con = sqlite3.connect("college.db")
cur = con.cursor()

cur.execute("DELETE FROM students WHERE marks < 40")

con.commit()
print("Low-scoring records deleted!")

con.close()