import sqlite3

con = sqlite3.connect("college.db")
cur = con.cursor()

cur.execute("""
CREATE TABLE IF NOT EXISTS students(
    id INTEGER PRIMARY KEY,
    name TEXT,
    age INTEGER,
    marks REAL
)
""")
con.commit()

while True:
    print("\n1. Add Student")
    print("2. View Students")
    print("3. Update Marks")
    print("4. Delete Student")
    print("5. Exit")

    choice = input("Enter choice: ")

    if choice == "1":
        name = input("Enter name: ")
        age = int(input("Enter age: "))
        marks = float(input("Enter marks: "))

        cur.execute(
            "INSERT INTO students(name, age, marks) VALUES (?, ?, ?)",
            (name, age, marks)
        )
        con.commit()
        print("Student added successfully!")

    elif choice == "2":
        cur.execute("SELECT * FROM students")

        for row in cur.fetchall():
            print(row)

    elif choice == "3":
        sid = int(input("Enter student ID: "))
        marks = float(input("Enter new marks: "))

        cur.execute(
            "UPDATE students SET marks = ? WHERE id = ?",
            (marks, sid)
        )
        con.commit()
        print("Marks updated!")

    elif choice == "4":
        sid = int(input("Enter student ID: "))

        cur.execute("DELETE FROM students WHERE id = ?", (sid,))
        con.commit()
        print("Student deleted!")

    elif choice == "5":
        print("Exiting application...")
        break

    else:
        print("Invalid choice!")

con.close()