s = {10, 20, 30, 40, 50}
print("Length:", len(s))