s = {15, 5, 30, 10, 25}

print("Maximum:", max(s))
print("Minimum:", min(s))