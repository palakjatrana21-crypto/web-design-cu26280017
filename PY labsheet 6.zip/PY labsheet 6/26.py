sentence = "Python is easy and Python is useful"
words = set(sentence.lower().split())

print(sorted(words))