s = {10, "Hello", 3.5, True}
print(s)