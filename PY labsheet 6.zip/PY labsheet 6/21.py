numbers = [10, 20, 10, 30, 20, 40]

s = set(numbers)
print("Distinct elements:", len(s))