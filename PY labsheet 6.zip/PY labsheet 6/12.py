a = {1, 2, 3, 4}
b = {3, 4, 5, 6}

print("Intersection:", a.intersection(b))