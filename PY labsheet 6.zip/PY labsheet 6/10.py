s = {10, 20, 30}

for item in sorted(s):
    print(item)