numbers = [10, 20, 10, 30, 20, 40]

result = list(set(numbers))
print(sorted(result))