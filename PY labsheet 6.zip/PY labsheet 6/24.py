text = "hello"
s = set(text)

print(s)