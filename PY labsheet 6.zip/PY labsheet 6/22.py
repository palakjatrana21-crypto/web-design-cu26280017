numbers = [10, 20, 10, 30, 20, 40]
seen = set()
duplicates = set()

for n in numbers:
    if n in seen:
        duplicates.add(n)
    else:
        seen.add(n)

print("Duplicates:", sorted(duplicates))
