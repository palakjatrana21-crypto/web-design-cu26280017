s1 = set("hello")
s2 = set("world")

common = s1.intersection(s2)
print("Common letters:", sorted(common))