s = frozenset([10, 20, 30])

print("Frozen set:", s)
print("Length:", len(s))
print("Element exists:", 20 in s)