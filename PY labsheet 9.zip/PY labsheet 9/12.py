import sqlite3

con = sqlite3.connect("college.db")
cur = con.cursor()

cur.execute(
    "INSERT INTO students VALUES (?, ?, ?)",
    (1, "Aman", 85)
)

con.commit()
con.close()

print("Record inserted!")