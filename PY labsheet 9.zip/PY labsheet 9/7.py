books = []

while True:
    print("\n1.Add  2.View  3.Update  4.Delete  5.Exit")
    choice = input("Enter choice: ")

    if choice == "1":
        books.append(input("Enter book name: "))
        print("Book added!")

    elif choice == "2":
        print(books)

    elif choice == "3":
        old = input("Enter book name: ")
        if old in books:
            books[books.index(old)] = input("Enter new name: ")
            print("Book updated!")
        else:
            print("Book not found")

    elif choice == "4":
        name = input("Enter book name: ")
        if name in books:
            books.remove(name)
            print("Book deleted!")
        else:
            print("Book not found")

    elif choice == "5":
        break

    else:
        print("Invalid choice")