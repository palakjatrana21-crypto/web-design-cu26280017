import sqlite3

con = sqlite3.connect("college.db")
cur = con.cursor()

cur.execute("SELECT * FROM students ORDER BY marks DESC LIMIT 1")

student = cur.fetchone()

if student:
    print("Highest scoring student:", student)
else:
    print("No student records found")

con.close()