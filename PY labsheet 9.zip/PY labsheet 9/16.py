import sqlite3

con = sqlite3.connect("college.db")
cur = con.cursor()

roll = int(input("Enter roll number: "))

cur.execute("DELETE FROM students WHERE roll = ?", (roll,))
con.commit()

if cur.rowcount:
    print("Record deleted!")
else:
    print("Student not found")

con.close()