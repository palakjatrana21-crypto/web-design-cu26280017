students = [
    {"roll": 1, "name": "Aman", "marks": 85},
    {"roll": 2, "name": "Riya", "marks": 90},
    {"roll": 3, "name": "Rahul", "marks": 75}
]

print("Student records created successfully!")