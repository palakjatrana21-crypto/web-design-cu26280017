# Write data
with open("students.txt", "w") as f:
    f.write("1 Aman 85\n")
    f.write("2 Riya 90\n")

# Read data
with open("students.txt", "r") as f:
    print(f.read())