import sqlite3

con = sqlite3.connect("college.db")
cur = con.cursor()

cur.execute("""
CREATE TABLE IF NOT EXISTS students(
    roll INTEGER PRIMARY KEY,
    name TEXT,
    marks REAL
)
""")
con.commit()

while True:
    print("\n1. Add Student")
    print("2. View Students")
    print("3. Update Marks")
    print("4. Delete Student")
    print("5. Exit")

    ch = input("Enter choice: ")

    if ch == "1":
        roll = int(input("Enter roll number: "))
        name = input("Enter name: ")
        marks = float(input("Enter marks: "))

        try:
            cur.execute(
                "INSERT INTO students VALUES (?, ?, ?)",
                (roll, name, marks)
            )
            con.commit()
            print("Student added!")
        except sqlite3.IntegrityError:
            print("Roll number already exists!")

    elif ch == "2":
        cur.execute("SELECT * FROM students")

        for row in cur.fetchall():
            print(row)

    elif ch == "3":
        roll = int(input("Enter roll number: "))
        marks = float(input("Enter new marks: "))

        cur.execute(
            "UPDATE students SET marks = ? WHERE roll = ?",
            (marks, roll)
        )
        con.commit()

        if cur.rowcount:
            print("Marks updated!")
        else:
            print("Student not found")

    elif ch == "4":
        roll = int(input("Enter roll number: "))

        cur.execute("DELETE FROM students WHERE roll = ?", (roll,))
        con.commit()

        if cur.rowcount:
            print("Student deleted!")
        else:
            print("Student not found")

    elif ch == "5":
        print("Exiting application...")
        break

    else:
        print("Invalid choice!")

con.close()