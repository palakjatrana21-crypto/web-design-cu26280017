import json

file = "students.json"

def read_data():
    try:
        with open(file, "r") as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return []

def save_data(data):
    with open(file, "w") as f:
        json.dump(data, f)

while True:
    print("\n1.Add 2.View 3.Update 4.Delete 5.Exit")
    ch = input("Enter choice: ")
    data = read_data()

    if ch == "1":
        roll = int(input("Roll: "))
        name = input("Name: ")
        marks = float(input("Marks: "))
        data.append({"roll": roll, "name": name, "marks": marks})
        save_data(data)
        print("Record added!")

    elif ch == "2":
        print(data)

    elif ch == "3":
        roll = int(input("Enter roll: "))
        for s in data:
            if s["roll"] == roll:
                s["marks"] = float(input("New marks: "))
                save_data(data)
                print("Record updated!")
                break
        else:
            print("Student not found")

    elif ch == "4":
        roll = int(input("Enter roll: "))
        new_data = [s for s in data if s["roll"] != roll]

        if len(new_data) < len(data):
            save_data(new_data)
            print("Record deleted!")
        else:
            print("Student not found")

    elif ch == "5":
        break

    else:
        print("Invalid choice")