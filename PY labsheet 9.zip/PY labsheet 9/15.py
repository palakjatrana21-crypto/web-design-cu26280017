import sqlite3

con = sqlite3.connect("college.db")
cur = con.cursor()

roll = int(input("Enter roll number: "))
marks = float(input("Enter new marks: "))

cur.execute(
    "UPDATE students SET marks = ? WHERE roll = ?",
    (marks, roll)
)

con.commit()

if cur.rowcount:
    print("Marks updated!")
else:
    print("Student not found")

con.close()