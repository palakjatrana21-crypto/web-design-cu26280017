products = []

# Create
products.append({"id": 1, "name": "Pen", "price": 10})

# Read
print("Products:", products)

# Update
products[0]["price"] = 15
print("Updated:", products)

# Delete
products = [p for p in products if p["id"] != 1]
print("Deleted:", products)