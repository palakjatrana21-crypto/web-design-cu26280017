import sqlite3

con = sqlite3.connect("college.db")
cur = con.cursor()

roll = int(input("Enter roll number: "))
cur.execute("SELECT * FROM students WHERE roll = ?", (roll,))

row = cur.fetchone()

if row:
    print(row)
else:
    print("Student not found")

con.close()