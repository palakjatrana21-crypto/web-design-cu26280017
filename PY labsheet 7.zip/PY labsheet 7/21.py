import csv

with open("students.csv", "w", newline="") as f:
    writer = csv.writer(f)
    writer.writerow(["Name", "Marks"])
    writer.writerow(["Aman", 85])
    writer.writerow(["Riya", 90])

print("CSV file created")