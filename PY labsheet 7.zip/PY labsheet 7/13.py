f = open("numbers.txt", "r")
numbers = list(map(float, f.read().split()))
f.close()

print("Sum:", sum(numbers))
print("Average:", sum(numbers) / len(numbers))