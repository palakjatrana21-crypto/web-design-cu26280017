import csv

with open("students.csv", "r") as f:
    reader = csv.DictReader(f)
    marks = [float(row["Marks"]) for row in reader]

if marks:
    print("Average marks:", sum(marks) / len(marks))
else:
    print("No records found")