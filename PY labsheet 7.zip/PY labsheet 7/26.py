import csv

with open("students.csv", "r") as f:
    data = list(csv.reader(f))

with open("copy.csv", "w", newline="") as f:
    writer = csv.writer(f)
    writer.writerows(data)

print("CSV file copied")