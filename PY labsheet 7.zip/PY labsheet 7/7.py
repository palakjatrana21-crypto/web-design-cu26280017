f = open("data.txt", "w")

n = int(input("Enter number of lines: "))

for i in range(n):
    line = input("Enter line: ")
    f.write(line + "\n")

f.close()
print("Data saved successfully")