f = open("data.txt", "r")
text = f.read()
words = text.split()

print("Total words:", len(words))
f.close()