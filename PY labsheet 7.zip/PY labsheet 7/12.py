f = open("data.txt", "r")
words = f.read().lower().split()
f.close()

word = input("Enter word: ").lower()

print("Occurrences:", words.count(word))