import csv

with open("merged.csv", "w", newline="") as out:
    writer = csv.writer(out)

    for filename in ["file1.csv", "file2.csv"]:
        with open(filename, "r") as f:
            reader = csv.reader(f)
            next(reader, None)
            writer.writerows(reader)

print("CSV files merged successfully")