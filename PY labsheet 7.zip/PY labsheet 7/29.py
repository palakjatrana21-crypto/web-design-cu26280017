import csv

name = input("Enter student name: ")

with open("students.csv", "r") as f:
    reader = csv.DictReader(f)
    found = False

    for row in reader:
        if row["Name"].lower() == name.lower():
            print(row)
            found = True

    if not found:
        print("Student not found")