import csv

with open("students.csv", "r") as f:
    students = list(csv.DictReader(f))

if students:
    top = max(students, key=lambda x: float(x["Marks"]))
    print("Highest marks:", top["Marks"])
    print("Student:", top["Name"])
else:
    print("No records found")