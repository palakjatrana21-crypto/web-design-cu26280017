import csv

with open("students.csv", "a", newline="") as f:
    writer = csv.writer(f)
    writer.writerow(["Rahul", 80])

print("Record added successfully")